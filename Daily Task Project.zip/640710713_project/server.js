const express = require('express');
const fs = require('fs');
const path = require('path');  // เพิ่มการนำเข้า path
const app = express();

app.use(express.static(path.join(__dirname, 'public'))); // ตั้งค่า static files ให้สามารถเข้าถึงได้จากโฟลเดอร์ public
app.use(express.json()); // รองรับการ parse JSON body
app.use(express.urlencoded({ extended: true })); // รองรับการ parse URL-encoded body

// นำเข้าข้อมูลจาก db.json
let tasks = require('./db.json');

// เส้นทางสำหรับดึงข้อมูลกิจกรรมทั้งหมด
app.get('/tasks', (req, res) => {
  res.json(tasks); // ส่งข้อมูลกิจกรรมทั้งหมดกลับไป
});

// เส้นทางสำหรับดึงกิจกรรมตามวัน
app.get('/tasks/:date', (req, res) => {
  const date = req.params.date;
  const dayTasks = tasks.find(task => task.date === date);

  if (dayTasks) {
    res.json(dayTasks.tasks); // ส่งกิจกรรมในวันนั้นๆ
  } else {
    res.status(404).json({ message: 'Tasks not found for this date' });
  }
});

// เส้นทาง POST สำหรับเพิ่มกิจกรรมใหม่
app.post('/tasks', (req, res) => {
  const { date, time, description } = req.body;

  // ค้นหาวันที่ใน db.json
  let day = tasks.find(task => task.date === date);
  if (!day) {
    // ถ้าวันนี้ยังไม่มีข้อมูลกิจกรรม ให้เพิ่มวันใหม่
    day = { date, tasks: [] };
    tasks.push(day);
  }

  // เพิ่มกิจกรรมใหม่ในวันนั้น
  day.tasks.push({ time, description });

  // บันทึกข้อมูลใหม่ลงใน db.json
  fs.writeFile('./db.json', JSON.stringify(tasks, null, 2), (err) => {
    if (err) {
      res.status(500).json({ message: 'Error saving task' });
    } else {
      res.status(201).json(day); // ส่งกลับข้อมูลที่เพิ่ม
    }
  });
});

app.post('/tasks/date', (req, res) => {
    const { date } = req.body;

    // ตรวจสอบว่าใน db.json มีวันที่นี้อยู่แล้วหรือยัง
    const existingDay = tasks.find(task => task.date === date);
    if (existingDay) {
        return res.status(400).json({ message: 'Date already exists' });
    }

    // ถ้ายังไม่มี ให้เพิ่มวันใหม่
    const newDay = { date, tasks: [] };
    tasks.push(newDay);

    // บันทึกข้อมูลใหม่ลงใน db.json
    fs.writeFile('./db.json', JSON.stringify(tasks, null, 2), (err) => {
        if (err) {
            return res.status(500).json({ message: 'Error saving date' });
        } else {
            res.status(201).json(newDay); // ส่งกลับวันที่ที่เพิ่มใหม่
        }
    });
});

// เส้นทาง PUT สำหรับแก้ไขกิจกรรม
app.put('/tasks/:date/:time', (req, res) => {
  const { date, time } = req.params;
  const { description } = req.body;

  const day = tasks.find(task => task.date === date);
  if (!day) {
    return res.status(404).json({ message: 'Tasks not found for this date' });
  }

  const task = day.tasks.find(t => t.time === time);
  if (!task) {
    return res.status(404).json({ message: 'Task not found for this time' });
  }

  task.description = description;

  // บันทึกข้อมูลใหม่ลงใน db.json
  fs.writeFile('./db.json', JSON.stringify(tasks, null, 2), (err) => {
    if (err) {
      res.status(500).json({ message: 'Error saving task' });
    } else {
      res.json(task); // ส่งกลับกิจกรรมที่แก้ไข
    }
  });
});

// เส้นทาง DELETE สำหรับลบกิจกรรม
app.delete('/tasks/:date/:time', (req, res) => {
  const { date, time } = req.params;

  const day = tasks.find(task => task.date === date);
  if (!day) {
    return res.status(404).json({ message: 'Tasks not found for this date' });
  }

  const taskIndex = day.tasks.findIndex(t => t.time === time);
  if (taskIndex === -1) {
    return res.status(404).json({ message: 'Task not found for this time' });
  }

  day.tasks.splice(taskIndex, 1); // ลบกิจกรรม

  // บันทึกข้อมูลใหม่ลงใน db.json
  fs.writeFile('./db.json', JSON.stringify(tasks, null, 2), (err) => {
    if (err) {
      res.status(500).json({ message: 'Error deleting task' });
    } else {
      res.status(204).send(); // ส่งกลับสถานะ 204 (No Content)
    }
  });
});

// เส้นทาง DELETE สำหรับลบกิจกรรมทั้งหมดในวันนั้น
app.delete('/tasks/:date', (req, res) => {
  const { date } = req.params;
  console.log(`Attempting to delete tasks for date: ${date}`);  // Debug

  // ค้นหาวันที่ที่ต้องการลบ
  const dayIndex = tasks.findIndex(task => task.date === date);
  if (dayIndex === -1) {
      console.log(`Tasks not found for date: ${date}`);
      return res.status(404).json({ message: 'Tasks not found for this date' });
  }

  // ลบกิจกรรมทั้งหมดในวันนั้น
  tasks.splice(dayIndex, 1);
  console.log(`Deleted tasks for date: ${date}`);  // Debug

  // บันทึกข้อมูลใหม่ลงใน db.json
  fs.writeFile('./db.json', JSON.stringify(tasks, null, 2), (err) => {
      if (err) {
          console.error('Error deleting tasks for this date');
          res.status(500).json({ message: 'Error deleting tasks for this date' });
      } else {
          res.status(204).send(); // ส่งกลับสถานะ 204 (No Content)
      }
  });
});

// ตั้งค่าให้เซิร์ฟเวอร์รันบนพอร์ตที่กำหนด
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
