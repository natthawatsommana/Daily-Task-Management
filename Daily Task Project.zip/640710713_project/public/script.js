document.addEventListener('DOMContentLoaded', () => {
    // แสดงกิจกรรมทั้งหมดเมื่อโหลดหน้า
    fetchTasks();

    // ฟอร์มการเพิ่มกิจกรรม
    const addTaskForm = document.getElementById('add-task-form');
    addTaskForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const date = document.getElementById('date').value;
        const time = document.getElementById('time').value;
        const description = document.getElementById('description').value;

        // ส่งคำขอ POST เพื่อเพิ่มกิจกรรม
        const response = await fetch('/tasks', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ date, time, description }),
        });

        if (response.ok) {
            fetchTasks(); // รีเฟรชรายการกิจกรรม
        } else {
            alert('Error adding task');
        }
    });
});

// ฟังก์ชันดึงข้อมูลกิจกรรม
async function fetchTasks() {
    const response = await fetch('/tasks');
    const tasks = await response.json();

    const taskListContainer = document.getElementById('task-list');
    taskListContainer.innerHTML = ''; // ล้างรายการเดิม

    // เรียงลำดับวันที่จากน้อยไปมาก
    tasks.sort((a, b) => new Date(a.date) - new Date(b.date));

    tasks.forEach(day => {
        const dayDiv = document.createElement('div');
        const dayTitle = document.createElement('h3');
        dayTitle.textContent = day.date;
        dayDiv.appendChild(dayTitle);

        // ปุ่มลบวัน
        const deleteDayButton = document.createElement('button');
        deleteDayButton.textContent = 'ลบวันที่';
        deleteDayButton.onclick = () => deleteDay(day.date);
        dayDiv.appendChild(deleteDayButton);

        // เรียงลำดับเวลาในแต่ละวันจากน้อยไปมาก
        day.tasks.sort((taskA, taskB) => {
            const [hourA, minuteA] = taskA.time.split(':').map(Number);
            const [hourB, minuteB] = taskB.time.split(':').map(Number);
            return hourA === hourB ? minuteA - minuteB : hourA - hourB;
        });

        day.tasks.forEach(task => {
            const taskDiv = document.createElement('div');
            taskDiv.classList.add('task');
            taskDiv.innerHTML = `
                <strong>${task.time}</strong>: ${task.description}
                <button class="edit" onclick="editTask('${day.date}', '${task.time}')">แก้ไข</button>
                <button class="delete" onclick="deleteTask('${day.date}', '${task.time}')">ลบ</button>
            `;
            dayDiv.appendChild(taskDiv);
        });

        taskListContainer.appendChild(dayDiv);
    });
}

// ฟังก์ชันลบกิจกรรม
async function deleteTask(date, time) {
    const response = await fetch(`/tasks/${date}/${time}`, {
        method: 'DELETE',
    });

    if (response.ok) {
        fetchTasks(); // รีเฟรชรายการกิจกรรม
    } else {
        alert('Error deleting task');
    }
}

// ฟังก์ชันแก้ไขกิจกรรม
async function editTask(date, time) {
    const newDescription = prompt('ใส่ข้อความที่ต้องการแก้ไข :');
    if (!newDescription) return;

    const response = await fetch(`/tasks/${date}/${time}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ description: newDescription }),
    });

    if (response.ok) {
        fetchTasks(); // รีเฟรชรายการกิจกรรม
    } else {
        alert('Error editing task');
    }
}

// ฟังก์ชันลบกิจกรรมทั้งหมดในวันนั้น
async function deleteDay(date) {
    const response = await fetch(`/tasks/${date}`, {
        method: 'DELETE',
    });

    if (response.ok) {
        alert('ลบวันที่สำเร็จ');
        fetchTasks(); // รีเฟรชรายการกิจกรรม
    } else {
        alert('Error deleting tasks for this day');
    }
}
